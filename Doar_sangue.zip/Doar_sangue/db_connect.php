<?php 

$conn= new mysqli('localhost','root','','blood_doar_db')or die("Could not connect to mysql".mysqli_error($con));
